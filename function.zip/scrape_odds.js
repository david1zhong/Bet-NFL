const axios = require('axios');

exports.handler = async (event) => {
  try {
    const apiKey = process.env.API_KEY || 'API_KEY';
    const sportKey = 'americanfootball_nfl';
    const regions = 'us';
    const markets = 'h2h,spreads,totals';
    const oddsFormat = 'american';
    const dateFormat = 'iso';

    const response = await axios.get(`https://api.the-odds-api.com/v4/sports/${sportKey}/odds`, {
      params: {
        apiKey,
        regions,
        markets,
        oddsFormat,
        dateFormat,
      }
    });

    const draftKingsGames = response.data
      .map(game => {
        const dk = game.bookmakers.find(b => b.key === "draftkings");
        if (!dk) return null;

        return {
          home_team: game.home_team,
          away_team: game.away_team,
          commence_time: game.commence_time,
          spreads: dk.markets.find(m => m.key === "spreads")?.outcomes || [],
          totals: dk.markets.find(m => m.key === "totals")?.outcomes || [],
          h2h: dk.markets.find(m => m.key === "h2h")?.outcomes || []
        };
      })
      .filter(Boolean);

    console.log(JSON.stringify(draftKingsGames, null, 2));
    console.log('Remaining requests:', response.headers['x-requests-remaining']);
    console.log('Used requests:', response.headers['x-requests-used']);

    return {
      statusCode: 200,
      body: JSON.stringify({ data: draftKingsGames }),
    };

  } catch (error) {
    console.error('Error fetching odds:', error.response?.status, error.response?.data);

    return {
      statusCode: error.response?.status || 500,
      body: JSON.stringify({ error: error.message || 'Unknown error' }),
    };
  }
};
